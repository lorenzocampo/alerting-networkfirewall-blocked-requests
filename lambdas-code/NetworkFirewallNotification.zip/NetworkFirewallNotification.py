import gzip
import json
import base64
import boto3
import logging
import os

logger = logging.getLogger(__name__)

def lambda_handler(event, context):
    try:
        json_log_events = decode_data_event(event)
    except Exception as e:
        logger.info("Error when decoding data event", e)

    try:
        load_variables(json_log_events)
    except Exception as e:
        logger.info("Error when loading variables from event", e)
    
    try:
        send_email(account_id,region,src_ip,src_port,dest_ip,dest_port,proto,alert_action,reason_for_blocking,domain,app_proto,ses_emails_sender,email_list)
    except Exception as e:
        logger.info("Error when sending email", e)

def decode_data_event(event):
    cw_data = event['awslogs']['data']
    compressed_payload = base64.b64decode(cw_data)
    uncompressed_payload = gzip.decompress(compressed_payload)
    payload = json.loads(uncompressed_payload)
    log_events = payload['logEvents']
    for log_event in log_events:
        json_log_event = json.loads(log_event['message'])
    return json_log_event
    
def load_variables(json_log_events):
    global src_ip
    global src_port
    global dest_ip
    global dest_port
    global proto
    global alert_action
    global reason_for_blocking
    global domain
    global app_proto
    global ses_emails_sender
    global email_list
    global account_id
    global region
    src_ip = json_log_events['event']['src_ip']
    src_port = str(json_log_events['event']['src_port'])
    dest_ip = json_log_events['event']['dest_ip']
    dest_port = str(json_log_events['event']['dest_port'])
    proto = json_log_events['event']['proto']
    alert_action = json_log_events['event']['alert']['action']
    reason_for_blocking = json_log_events['event']['alert']['signature']
    domain = json_log_events['event']['tls']['sni']
    app_proto = json_log_events['event']['app_proto']
    ses_emails_sender = os.environ['ses_emails_sender']
    ses_emails_recipients = json.loads(os.environ['ses_emails_recipients']).values()
    email_list = []
    for email in ses_emails_recipients:
        email_list.append(email)
    account_id = os.environ['account_id']
    region = os.environ['region']

def send_email(account_id,region,src_ip,src_port,dest_ip,dest_port,proto,alert_action,reason_for_blocking,domain,app_proto,ses_emails_sender,email_list):
    SENDER = ses_emails_sender
    RECIPIENT = email_list
    SUBJECT = "[Network Firewall] - A request has been blocked in the Network Firewall of the account " + account_id
    CHARSET = "UTF-8"

    BODY_HTML = """
    <html>
    <head></head>
    <body>
      <p><br><b>- Source IP:</b> {src_ip}</br>
      <p><br><b>- Source Port:</b> {src_port}</br>
      <p><br><b>- Dest IP:</b> {dest_ip}</br>
      <p><br><b>- Dest Port:</b> {dest_port}</br>
      <p><br><b>- Protocol:</b> {proto}</br>
      <p><br><b>- Alert action:</b> {alert_action}</br>
      <p><br><b>- Reason for blocking:</b> {reason_for_blocking}</br>
      <p><br><b>- Domain:</b> {domain}</br>
      <p><br><b>- App protocol:</b> {app_proto}</br>
    </body>
    </html>
    """

    NEW_BODY_HTML = BODY_HTML.format(account_id=account_id,region=region,src_ip=src_ip,src_port=src_port,dest_ip=dest_ip,dest_port=dest_port,proto=proto,alert_action=alert_action,reason_for_blocking=reason_for_blocking,domain=domain,app_proto=app_proto,ses_emails_sender=ses_emails_sender,email_list=email_list)

    client = boto3.client('ses',region_name=region)
    
    for mail in RECIPIENT:
        try:
            response = client.send_email(
                Destination={
                    'ToAddresses': [
                        mail,
                    ],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': CHARSET,
                            'Data': NEW_BODY_HTML,
                        },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                        },
                    },
                Source=SENDER,
            )
        except Exception as e:
            logger.info("Error when sending email", e)
        else:
            print("Email sent! Message ID: " + response['MessageId'])